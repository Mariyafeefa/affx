package com.example.afeefa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AfeefaApplicationTests {

	@Test
	void contextLoads() {
	}

}
