package com.example.afeefa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AfeefaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AfeefaApplication.class, args);
	}

}
